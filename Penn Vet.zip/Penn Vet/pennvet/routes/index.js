/**
 * Main Web route handling
 */

// Note the use of the exports object. Each function that we
// assign to exports.XXX is callable by outside modules,
// and we can "hook" to it via routes.XXX.
// These are our key-value stores
var PythonShell = require('python-shell');
var jsonfile = require('jsonfile');
var path = require('path');
var users;
var friends;
var userids;
var appointments;
var active_appmts;
var messages;
var pythonDir = path.dirname(require.main.filename) + "/python";
var target = "20160601";

// We export the init() function to initialize
// our KVS values
exports.init = function(usrs, uids, appmts, aappmts, msgs, callback) {
	users = usrs;
	userids = uids;
	appointments = appmts;
	active_appmts = aappmts;
	messages = msgs;

	callback();
};

/**
 * Default index page fetches some content and returns it
 */
exports.index = function(req, res) {
	var t = '';

	// See if the session object in the cookie has
	// been set, and change title correspondingly
	if (!req.session.loadedData)
		t = 'User login or creation';
	else
		t = 'User login or creation logged in (previously fetched data)';
	
	// check if the session object has id recored
	if (req.session.uid != null) {
		t = 'Already logged in, please go to your home page.';
	}
	res.render('index', {
		title : t, fullname: null, uid: null 
	});
}

exports.getData = function(req, res) {
	// TODO: update this to do the right thing,
	// or discard this function

	// Dummy response: Consult the KVS and
	// get the list of keys (users who have friends)

}

exports.validate = function(req, res) {
	console.log(req.body);
	var username = req.body.username;
	var password = req.body.password;

	users.get(username, function(err, values) {
		if (err)
			throw err;
		else if (values == null) {
			// console.log("username not found");
			res.send("false");
		} else {
			var user = JSON.parse(values);
			if (user.password === password) {
				req.session.uid = parseInt(user.userid);
				req.session.type = user.type;
				req.session.fullname = user.fullname;
				res.send("true");
				// console.log("valid combination");
			} else {
				res.send("false");
				// console.log("incorrect password");
			}
		}
	});
}

exports.logout = function(req, res) {
	// show the user as not logged in by removing the 
	// userid from the loggedin table

	// set the user session variables to null
	req.session.uid = null;
	req.session.fullname = null;
	// return to the login page
	res.render('index', { title: 'Please Log In', fullname: null, uid: null });

}

exports.createaccount = function(req, res) {
	// console.log(req.body);
	var username = req.body.username;
	var password = req.body.password;
	var fullname = req.body.fullname;
	var type = req.body.type;
	var userid;

	// check if the user name exists
	users.get(username, function(err, values) {
		if (err)
			throw err;
		// if we can find this user name, send the message
		else if (values != null) {
			// console.log("exist");
			res.send("exist");
		} else {
			// if the user name doesn't exist, we first find the user id
			// by scanning the current userids table
			userids.scanKeys(function(err, values) {
				if (err)
					throw err;
				else {
					// if there is nothing in the userids table, we use 1
					// console.log(values);
					if (values.length === 0)
						userid = 1;
					// otherwise we find the biggest number and plus 1
					else {
						values.sort(function(a, b){return b-a});
						userid = parseInt(values[0]) + 1;
					}
					// put the (user id, user name) into userids table
					userids.put(userid.toString(), username, function(err,
							values) {
						if (err)
							throw err;
						else {
							console.log("add to userids:  " + userid.toString()
									+ "  " + username);
						}
					});
					// form the json object for the users table
					var json = '{ "fullname": "' + fullname + '", '
							+ '"email": "' + '", '
							+ '"password": "' + password + '", '
							+ '"userid": "' + userid.toString() + '", '
							+ '"type": "' + type + '" }';
					// put (username, json) into users table
					users.put(username, json, function(err, values) {
						if (err)
							throw err;
						else {
							console.log("add to users: " + username + "  "
									+ json);

							req.session.uid = userid;
							req.session.type = type;
							req.session.fullname = fullname;
							res.send("successful");
						}
					});
				}
			});
		}

	});

}

exports.createappointment = function(req, res) {
	// console.log(req.body);
	var patientid = req.body.patientid;
	var petname = req.body.petname;
	var ownername = req.body.ownername;
	var pettype = req.body.pettype;
	var type = req.body.type;
	var specificinfo = req.body.specificinfo;
	var date = req.body.date;
	var month = req.body.month;
	var year = req.body.year;
	var urgent = req.body.urgent;
	var sedation = req.body.sedation;
	var doctorname = req.body.doctorname;
	var doctorid = req.body.doctorid;

	var appointmentid;

	if (month.length == 1)
		month = "0" + month;
	if (date.length == 1)
		date = "0" + date;
	
	appointments.scanKeys(function(err, values) {
		if (err)
			throw err;
		else {
			// if there is nothing in the userids table, we use 1
			// console.log(values);
			if (values.length === 0)
				appointmentid = 0;
			// otherwise we find the biggest number and plus 1
			else {
				values.sort(function(a, b){return b-a});
				appointmentid = parseInt(values[0]) + 1;
			}
			// form the json object for the users table
			var json = '{ "appmtid": "' + appointmentid + '", '
					+ '"doctorname": "' + doctorname + '", '
					+ '"doctorid": "' + doctorid + '", '
					+ '"patientid": "' + patientid + '", '
					+ '"petname": "' + petname + '", '
					+ '"ownername": "' + ownername + '", '
					+ '"pettype": "' + pettype + '", '
					+ '"type": "' + type + '", '
					+ '"specificinfo": "' + specificinfo + '", '
					+ '"date": "' + date + '", '
					+ '"month": "' + month + '", '
					+ '"year": "' + year + '", '
					+ '"urgent": "' + urgent + '", '
					+ '"sedation": "' + sedation + '", '
					+ '"estimatedtime": "30", '
					+ '"actualtime": "" }';
			// console.log(json);
			// put (appointmentid, json) into users table
			        if (type == 'X-Ray')
                        type = 'XRay';

                    if (specificinfo == '')
                        specificinfo = 'chest'
                	var options = {
                		args: ['-e'+ urgent, '-o'+ ownername, '-p' + petname, '-t' + pettype, '-a'+appointmentid, '-s'+sedation, '-dDentistry' , '-x' + type, '-c' + specificinfo],
                		scriptPath : pythonDir
            		};

            		PythonShell.run('schedule.py', options, function(err, results){
            		    if (err)
            		        throw err;
            		    else{
            		    	console.log(results);
            		   }
            		});

			appointments.put(appointmentid.toString(), json, function(err, values) {
				if (err)
					throw err;
				else {
					console.log("add to appointments: " + appointmentid + "  " + json);
					res.send("successful");
				}
			});
			
			var fulldate = year + month + date;

			active_appmts.addToSet(fulldate, appointmentid.toString(), function(err) {
				if (err) throw err;
				else console.log(fulldate + "  " + appointmentid);
			})
			
			var message = "appointments for " + ownername + "'s " + petname + " added"; 
			var json2 = '{ "content": "' + message + '", '
					+ '"sender": "' + req.session.uid + '", '
					+ '"status": "' + "unread" + '" }';
			messages.addToSet("1", json2.toString(), function(err) {
				if (err) throw err;
			});
		}
	});
}
exports.start = function(req, res) {
	// start
        var n1 = req.url.indexOf("=");
        var n2 = req.url.substr(n1).indexOf("&");
        var type = req.url.substr(n1+1, n2-1);

        var options = {
            args: ['-q'+ type],
            scriptPath : pythonDir
        };

        PythonShell.run('start.py', options, function(err, results){
            if (err)
                throw err;
            else{
                console.log(results);
           }
        });
}

exports.finish = function(req, res) {
        console.log("finishing")
        var n1 = req.url.indexOf("=");
        var n2 = req.url.substr(n1).indexOf("&");
        var type = req.url.substr(n1+1, n2-1);

        var options = {
            args: ['-q'+ type],
            scriptPath : pythonDir
        };

        PythonShell.run('finish.py', options, function(err, results){
            if (err)
                throw err;
            else{
                console.log(results);
           }
        });
}
exports.updateappointment = function(req, res) {
	var appmtid = req.body.appmtid;
	var patientid = req.body.patientid;
	var petname = req.body.petname;
	var ownername = req.body.ownername;
	var pettype = req.body.pettype;
	var type = req.body.type;
	var specificinfo = req.body.specificinfo;
	var date = req.body.date;
	var month = req.body.month;
	var year = req.body.year;
	var urgent = req.body.urgent;
	var sedation = req.body.sedation;
	var doctorname = req.body.doctorname;
	var doctorid = req.body.doctorid;
	
	type = type.substring(0, type.length-1);
	pettype = pettype.substring(0, pettype.length-1);
	
	if (month.length == 1)
		month = "0" + month;
	if (date.length == 1)
		date = "0" + date;

	// form the json object for the users table
	var json = '{ "appmtid": "' + appmtid + '", '
			+ '"doctorname": "' + doctorname + '", '
			+ '"doctorid": "' + doctorid + '", '
			+ '"patientid": "' + patientid + '", '
			+ '"petname": "' + petname + '", '
			+ '"ownername": "' + ownername + '", '
			+ '"pettype": "' + pettype + '", '
			+ '"type": "' + type + '", '
			+ '"specificinfo": "' + specificinfo + '", '
			+ '"date": "' + date + '", '
			+ '"month": "' + month + '", '
			+ '"year": "' + year + '", '
			+ '"urgent": "' + urgent + '", '
			+ '"sedation": "' + sedation + '", '
			+ '"estimatedtime": "30", '
			+ '"actualtime": "" }';
	// put (appointmentid, json) into users table

	appointments.put(appmtid, json, function(err, values) {
		if (err)
			throw err;
		else {
			console.log("add to appointments: " + appmtid + "  " + json);
            var options = {
                args: ['-e'+ urgent, '-s'+ sedation, '-a' + appmtid],
                scriptPath : pythonDir
            };

            PythonShell.run('modify.py', options, function(err, results){
                if (err)
                    throw err;
                else{
                    console.log(results);
               }
            });
			res.send("successful");
		}
	});
	var message = "appointments for " + ownername + "'s " + petname + " modified"; 
	var json2 = '{ "content": "' + message + '", '
			+ '"sender": "' + req.session.uid + '", '
			+ '"status": "' + "unread" + '" }';

	console.log(req.session.uid);
	if (req.session.uid === 1) {
		messages.addToSet(doctorid, json2, function(err) {
			if (err) {throw err;}
		});
	}
	else {
		messages.addToSet("1", json2, function(err) {
			if (err) {throw err;}
		});
	}
}

exports.newappointment = function(req, res) {
	// modify
	var n1 = req.url.indexOf("=");
	var n2 = req.url.substr(n1).indexOf("&");
	var field1 = req.url.substr(n1+1, n2-1);
	// appmt id
	var n3 = req.url.substr(n1+1).indexOf("=") + n1+1;
	var n4 = req.url.substr(n3).indexOf("&");
	var field2 = req.url.substr(n3+1, n4-1);
	console.log(field2);
	// patientid
	var n5 = req.url.substr(n3+1).indexOf("=") + n3+1;
	var n6 = req.url.substr(n5).indexOf("&");
	var field3 = req.url.substr(n5+1, n6-1);
	
	var n7 = req.url.substr(n5+1).indexOf("=") + n5+1;
	var n8 = req.url.substr(n7).indexOf("&");
	var field4 = req.url.substr(n7+1, n8-1);

	var n9 = req.url.substr(n7+1).indexOf("=") + n7+1;
	var n10 = req.url.substr(n9).indexOf("&");
	var field5 = req.url.substr(n9+1, n10-1);

	var n11 = req.url.substr(n9+1).indexOf("=") + n9+1;
	var n12 = req.url.substr(n11).indexOf("&");
	var field6 = req.url.substr(n11+1, n12-1);

	var n13 = req.url.substr(n11+1).indexOf("=") + n11+1;
	var n14 = req.url.substr(n13).indexOf("&");
	var field7 = req.url.substr(n13+1, n14-1);

	var n15 = req.url.substr(n13+1).indexOf("=") + n13+1;
	var n16 = req.url.substr(n15).indexOf("&");
	var field8 = req.url.substr(n15+1, n16-1);
	
	var n17 = req.url.substr(n15+1).indexOf("=") + n15+1;
	var n18 = req.url.substr(n17).indexOf("&");
	var field9 = req.url.substr(n17+1, n18-1);

	var n19 = req.url.substr(n17+1).indexOf("=") + n17+1;
	var n20 = req.url.substr(n19).indexOf("&");
	var field10 = req.url.substr(n19+1, n20-1);
	
	var n21 = req.url.substr(n19+1).indexOf("=") + n19+1;
	var n22 = req.url.substr(n21).indexOf("&");
	var field11 = req.url.substr(n21+1, n22-1);
	
	var n23 = req.url.substr(n21+1).indexOf("=") + n21+1;
	var n24 = req.url.substr(n23).indexOf("&");
	var field12 = req.url.substr(n23+1, n24-1);
	
	var n25 = req.url.substr(n23+1).indexOf("=") + n23+1;
	var n26 = req.url.substr(n25).indexOf("&");
	var field13 = req.url.substr(n25+1, n26-1);
	
	var n27 = req.url.substr(n25+1).indexOf("=") + n25+1;
	var n28 = req.url.substr(n27).indexOf("&");
	var field14 = req.url.substr(n27+1, n28-1);

	var fullname = req.url.substr(n27+n28+1);
	fullname = decodeURIComponent(fullname);
	console.log(fullname);
	
	if (!req.session.uid) {
		// if the user is not logged in, show the login page
		res.render('index', { title: 'Please Log In' });
	}
	else {
		if (field1 == "false") {
			res.render('appointment', {
				title : 'Create a New Appointment',
				modify : false,
				doctorid : field2,
				fullname : req.session.fullname,
				uid : req.session.uid
			});
		}
		else {
			res.render('appointment', {
				title : 'Modify an Existing Appointment',
				modify : true,
				appmtid : field2,
				patientid : field3,
				petname : field4,
				ownername : field5,
				pettype : field6,
				type : field7,
				specificinfo : field8,
				date : field9,
				month : field10,
				year : field11,
				urgent : field12,			
				sedation : field13,	
				doctorid : field14,
				fullname : fullname,
				uid: req.session.uid 
			});
		}
	}
}

exports.signup = function(req, res) {

	// Trigger signup.ejs.

	res.render('signup', {
		title : 'Signup', fullname: null, uid: null 
	});
}
exports
exports.home = function(req, res) {

	var appmts_list = [];

	var today = new Date();
	var todayStr = "";


	console.log(req.session.uid);
	if (!req.session.uid) {
		// if the user is not logged in, show the login page
		res.render('index', { title: 'Please Log In', fullname: null, uid: null });
	}
	else {
		messages.getSet(req.session.uid.toString(), function(err, inbox){
			if (err) throw err;
			else {
				active_appmts.getSet(target, function(err, values){
					if (err)
						throw err;
					// if no active appmts found, render the home page with empty list
					else if (values == null) {
						res.render('home', {
							title : 'Home',
							fullname : req.session.fullname,
							uid : req.session.uid,
							type : req.session.type,
							'appmts_list': appmts_list,
							inbox : inbox
						});
					} else {
						var i;
						var finished = 0;
						var options = {scriptPath: pythonDir};
						PythonShell.run( 'update.py', options, function(err, results){
		                   if(err) throw err;
		                   else {
		                       console.log(results)
		                	   var count = 0;
		                	   for (i = 0; i < values.length; i++) {
									(function (appointmentid) {
									    var json = jsonfile.readFileSync('/Users/shiqi/Documents/Archive/2015 Fall/Senior Design/pennvet 2/pennvet');
									    if (i >= json.length)
									    {
									        finished++;
									        complete();
									        return
									    }
										var id = json[i].patient.appointmentID;
										var estimatedtime =  json[i].patient.estimatedTime;
										count++;
										appointments.get(id, function(err, info){
											if (err)
												throw err;
											else if (info == null) {
												appmts_list[appmts_list.length] = null;
												finished++;
												complete();
											} else {
												var temp = JSON.parse(info);
												temp.estimatedtime = estimatedtime;
												appmts_list[appmts_list.length] = JSON.stringify(temp);
												console.log(JSON.stringify(temp));

												finished++;
												complete();
											}
										});
									}(values[i]));
								}
								// check if all the appointments have been added to the list
								function complete() {
									console.log(finished);
									console.log(values.length);
									if (finished === values.length) {
										if (inbox != null) {
										messages.delSet(req.session.uid.toString(), function(err, values){
											if (err)
												throw err;
											else
//												res.render('home', {
//													title : 'Home',
//													fullname : req.session.fullname,
//													uid : req.session.uid,
//													type : req.session.type,
//													'appmts_list': appmts_list,
//													inbox : inbox
//												});
                                                console.log("RENDERING...")
										});
										}
										else 
											res.render('home', {
												title : 'Home',
												fullname : req.session.fullname,
												uid : req.session.uid,
												type : req.session.type,
												'appmts_list': appmts_list,
												inbox : inbox
											});
										//console.log("output: " + appmts_list);

									}
								}
		                   }
						});
						
					}
				});
			}
		});
	}
};

