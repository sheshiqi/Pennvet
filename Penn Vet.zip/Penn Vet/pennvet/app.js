/**
 * 
 */

var express = require('express');
var routes = require ('./routes');
var http = require('http');
var path = require('path');
var app = express();
var engine = require('ejs-locals');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var PythonShell = require('python-shell');
app.set('port', process.env.PORT || 8088);
app.engine('ejs', engine);
app.set('views', path.join( __dirname, 'views'));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true }));
app.use(bodyParser.json());
app.use( express.static( path.join( __dirname, 'public' )));
app.use("/bootstrap",express.static(__dirname + "/node_modules/bootstrap"));

app.use(cookieParser());
// TODO: update this with your PennKey
app.use(session({secret: 'sheshiqi'}));

/////////////////

var aws = require("./keyvaluestore.js");

var users = new aws('users');
var userids = new aws('userids');
var appointments = new aws('appointments');
var active_appmts = new aws('active_appmts');
var messages = new aws('messages');

messages.init(function() {
	users.init(function() {
		userids.init(function() {
			appointments.init(function() {
				active_appmts.init(function() {
					routes.init(users, userids, appointments, active_appmts, messages, function() {
						app.get( '/', routes.index );
						app.get( '/index.html', routes.index );
						app.get( '/getdata', routes.getData );
						
						app.post( '/validate', routes.validate );				
						app.get( '/signup', routes.signup );
						app.post( '/createaccount', routes.createaccount );
						app.get( '/newappointment', routes.newappointment );
						app.post( '/createappointment', routes.createappointment );
						app.post( '/updateappointment', routes.updateappointment );
						app.get( '/home', routes.home );
						app.get( '/logout', routes.logout);
						app.get( '/start', routes.start);
                        app.get( '/finish', routes.finish);
					
						/////////////////////
						
						http.createServer( app ).listen( app.get( 'port' ), function(){
							  console.log( 'Open browser to http://localhost:' + app.get( 'port' ));
							} );
					});
				});
			});
		});
	});
});


