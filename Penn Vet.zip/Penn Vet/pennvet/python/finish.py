from queue import task
from queue import queue
import update
import json
import os
import sys, getopt
import time

xrayQueue = queue(type = "XRay", baseline = 20 * 60)
CTQueue = queue(type = "CT", baseline = 60 * 60)
MRIQueue = queue(type = "MRI", baseline = 60 * 60)
jsonFile = 'data.json'
try:
    opts, args = getopt.getopt(sys.argv[1:],"q:", ["queueType="])
except getopt.GetoptError:
    print 'finish.py -q <queueType> '
    sys.exit(2)

queueType = ""

for opt, arg in opts:
    if opt == '-h':
        print 'finish.py -q <queueType> '
        sys.exit()
    elif opt in ("-q", "--queueType"):
        queueType = arg

def finishTopTask():
    if queueType == 'CT':
        CTQueue.finishTask()
    elif queueType == 'MRI':
        MRIQueue.finishTask()
    else:
        xrayQueue.finishTask()


def finish():
    with open(jsonFile, 'r') as intputfile:
        feeds = json.load(intputfile)
        update.readJsonAndConstructQueue(feeds, xrayQueue, CTQueue, MRIQueue)

    with open(jsonFile, mode='w') as f:
        json.dump([], f)


    finishTopTask()

    with open(jsonFile, mode='r') as f:
        outfeeds = json.load(f)
        outfeeds = update.readQueueAndAppendJsonFeeds(xrayQueue,outfeeds)
        outfeeds = update.readQueueAndAppendJsonFeeds(CTQueue, outfeeds)
        outfeeds = update.readQueueAndAppendJsonFeeds(MRIQueue, outfeeds)

    with open(jsonFile, 'w') as outfile:
        print "############## FINISH A TASK ###############################"
        print json.dumps(outfeeds, indent=4, sort_keys=True)
        json.dump(outfeeds,outfile)

    return "12345"
finish()


