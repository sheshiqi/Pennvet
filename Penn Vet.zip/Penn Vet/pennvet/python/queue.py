import time
import datetime
import json

## TODO: currently queue is manipulating task some members directly, which isn't good


class task():
    def __init__(self, isEmergent=False, ownerName="", patientName="", patientType="", patientID=0, needSedation=False, department="",examType="", specificScan="", waitingTime=0, lastSyncedTime = 0, appointmentID = 0, isStarted = False):
        self.isEmergent = isEmergent
        self.ownerName = ownerName
        self.patientName = patientName
        self.patientType = patientType
        self.patientID = patientID
        self.needSedation = needSedation
        self.department = department
        self.examType = examType
        self.specificScan = specificScan
        self.waitingTime = waitingTime
        self.lastSyncedTime = lastSyncedTime
        self.appointmentID = appointmentID
        self.isStarted = isStarted

    def OnQueued(self, estimate):
        self.waitingTime = estimate
        self.lastSyncedTime = time.time()
        print(self.ownerName +  "'s task is scheduled. Extimated Waiting time is: " + str(self.waitingTime) + " mins")

    def OnFinish(self):
        print(self.ownerName + "'s task is finished!")

    def OnStart(self):
        self.isStarted = True
        print(self.ownerName + "'s task is just started")

    def showInfo(self):
        self.syncWaitTime()
        print(   "// ownerName:             " + self.ownerName + "\n"
                + "// Is Emergent:           " + str(self.isEmergent) + "\n"
                + "// Estimated Waiting Time:" + str(self.waitingTime.__int__()) + " mins \n")

    def syncWaitTime(self):
        deltaTime = time.time() - self.lastSyncedTime
        self.lastSyncedTime = time.time()
        self.waitingTime -= deltaTime
        self.waitingTime = max(0,  self.waitingTime)
        return self.waitingTime

class queue():
    def __init__(self, type="", baseline=0):
        self.type = type
        self.list = []
        self.baseline = baseline
        self.numEmergentTasks = 0

    def schedule(self, task):
        self.numEmergentTasks = 0;
        for t in self.list:
             if t.isEmergent == 'true' or t.isEmergent == 'True':
                self.numEmergentTasks += 1

        if task.isEmergent == 'false' or task.isEmergent == 'False' :
            self.list.append(task)
        else:
            self.list.insert(self.numEmergentTasks, task)
            self.updateTasks()
        task.OnQueued(self.calcSyncedTotalWaitTime(task = task))

    def startTask(self):
        if len(self.list) > 0:
            self.list[0].OnStart()

    def finishTask(self):
        self.list.remove(self.list[0])
        self.updateTasks()

    def listWaitingTasks(self):
        print("---------- Waiting List:" + self.type + "  ------------")
        c = 1
        for t in self.list:
            print("NO. " + str(c))
            c+=1
            t.showInfo()

    def cancel(self):
        self.list.remove()
        print 'Cancelling the task'

    def calcWaitTime(self, task):
        waitTime = self.baseline
        if task.department == 'Orthopedic':
            waitTime += 10 * 60

        if task.needSedation == 'true' or task.needSedation == 'True':
            waitTime += 15 * 60

        return waitTime

    def calcSyncedTotalWaitTime(self, task):
        index = self.list.index(task)
        totalWaitTime = 0
        # two cases here...there's one task already started or not
        # if self.currentTask.ownerName != '':
        #     totalWaitTime += self.currentTask.syncWaitTime()
        #     if index >= 0:
        #         for x in range(0, index):
        #             totalWaitTime += self.calcWaitTime(self.list[x])
        # el
        if index > 0 :
            totalWaitTime += self.list[0].waitingTime
            for x in range(1, index+1):
                totalWaitTime += self.calcWaitTime(self.list[x])
        else:
            if task.isStarted == True or task.isStarted == 'true' or task.isStarted == 'True':
                totalWaitTime += task.syncWaitTime()
            else:
                totalWaitTime += self.calcWaitTime(task)

        return totalWaitTime

    def updateTasks(self):
        for task in self.list:
            task.lastSyncedTime = time.time()
            task.waitingTime = self.calcSyncedTotalWaitTime(task)

## you can try make other type of queues and add tasks into it and test it.

