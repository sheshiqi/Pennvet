from queue import task
from queue import queue
import update
import json
import os
import sys, getopt
import time

xrayQueue = queue(type = "XRay", baseline = 20 * 60)
CTQueue = queue(type = "CT", baseline = 60 * 60)
MRIQueue = queue(type = "MRI", baseline = 60 * 60)
jsonFile = 'data.json'
try:
    opts, args = getopt.getopt(sys.argv[1:],"e:o:p:t:i:s:d:x:c:a:", ["isEmergent=",
                                                                     "ownerName=",
                                                                     "patientName=",
                                                                     "patientType=",
                                                                     "patientID=",
                                                                     "needSedation=",
                                                                     "department=",
                                                                     "examType=",
                                                                     "specificScan=",
                                                                     "appointmentID="
                                                                 ])
except getopt.GetoptError:
    print 'schedule.py -e <isEmergent> -o <ownerName> -p <patientName> -t <patientType> -i <patientID> -s <needSedation> -d <department> -x <examType> -c <specificScan> -a <appointmentID>'
    sys.exit(2)

isEmergent=False
ownerName="NA"
patientName="NA"
patientType="NA"
patientID=0
needSedation=False
department="NA"
examType="CT"
specificScan="NA"
appointmentID="1"

for opt, arg in opts:
    if opt == '-h':
         print 'schedule.py -e <isEmergent> -o <ownerName> -p <patientName> -t <patientType> -i <patientID> -s <needSedation> -d <department> -x <examType> -c <specificScan> -a <appointmentID>'
         sys.exit()
    elif opt in ("-e", "--isEmergent"):
        isEmergent = arg
    elif opt in ("-o", "--ownerName"):
        ownerName = arg
    elif opt in ("-p", "--patientName"):
        patientName = arg
    elif opt in ("-t", "--patientType"):
        patientType = arg
    elif opt in ("-i", "--patientID"):
        patientID = arg
    elif opt in ("-s", "--needSedation"):
        needSedation = arg
    elif opt in ("-d", "--department"):
        department = arg
    elif opt in ("-x", "--examType"):
        examType = arg
    elif opt in ("-c", "--specificScan"):
        specificScan = arg
    elif opt in ("-a", "--appointmentID"):
        appointmentID = arg

task1 = task(isEmergent,ownerName, patientName, patientType, patientID, needSedation, department,examType, specificScan, 0, 0, appointmentID, False)

def createTaskFromJson(jsonEntry):
    return task(jsonEntry['patient']['isEmergent'],
                jsonEntry['patient']['ownerName'],
                jsonEntry['patient']['patientName'],
                jsonEntry['patient']['patientType'],
                jsonEntry['patient']['patientID'],
                jsonEntry['patient']['needSedation'],
                jsonEntry['patient']['department'],
                jsonEntry['patient']['examType'],
                jsonEntry['patient']['specificScan'],
                0,
                0,
                jsonEntry['patient']['appointmentID'],
                False
                )


def scheduleNewTask(task):
    if task.examType == xrayQueue.type:
        xrayQueue.schedule(task)
    elif task.examType == CTQueue.type:
        CTQueue.schedule(task)
    elif task.examType == MRIQueue.type:
        MRIQueue.schedule(task)

def schedule(task):
    with open(jsonFile, 'r') as intputfile:
        feeds = json.load(intputfile)
        update.readJsonAndConstructQueue(feeds, xrayQueue, CTQueue, MRIQueue)

    with open(jsonFile, mode='w') as f:
        json.dump([], f)

    with open(jsonFile, mode='r') as f:
        outfeeds = json.load(f)
        outfeeds = update.readQueueAndAppendJsonFeeds(xrayQueue,outfeeds)
        outfeeds = update.readQueueAndAppendJsonFeeds(CTQueue, outfeeds)
        outfeeds = update.readQueueAndAppendJsonFeeds(MRIQueue, outfeeds)

    scheduleNewTask(task)
    newdata = {'patient':
                   { 'ownerName' : ownerName,
                    'patientName': patientName,
                    'isEmergent': isEmergent,
                    'patientType': patientType,
                    'patientID': patientID,
                    'needSedation': needSedation,
                    'department': department,
                     'examType': examType,
                     'specificScan':specificScan,
                    'waitingTime': task.waitingTime,
                    'lastSyncedTme':task.lastSyncedTime,
                    'appointmentID':appointmentID,
                    'isStarted' : False,
                    'estimatedTime' : time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(task.waitingTime + time.time()))
                    }
               }

    with open(jsonFile, 'w') as outfile:
        outfeeds.append(newdata)
        print "##############  SCHEDULING ###############################"
        print json.dumps(outfeeds, indent=4, sort_keys=True)
        json.dump(outfeeds,outfile)

schedule(task1)


