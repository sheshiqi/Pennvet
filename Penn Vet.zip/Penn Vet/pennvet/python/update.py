from queue import task
from queue import queue
import json
import os
import sys, getopt
import time

xrayQueue = queue(type = "XRay", baseline = 20 * 60)
CTQueue = queue(type = "CT", baseline = 60 * 60)
MRIQueue = queue(type = "MRI", baseline = 60 * 60)

jsonFile = 'data.json'
def createTaskFromJson(jsonEntry):
    return task(jsonEntry['patient']['isEmergent'],
                jsonEntry['patient']['ownerName'],
                jsonEntry['patient']['patientName'],
                jsonEntry['patient']['patientType'],
                jsonEntry['patient']['patientID'],
                jsonEntry['patient']['needSedation'],
                jsonEntry['patient']['department'],
                jsonEntry['patient']['examType'],
                jsonEntry['patient']['specificScan'],
                jsonEntry['patient']['waitingTime'],
                jsonEntry['patient']['lastSyncedTme'],
                jsonEntry['patient']['appointmentID'],
                jsonEntry['patient']['isStarted'])

def updateJsonTask(task):
    task.syncWaitTime()

def updateQueue():
    xrayQueue.updateTasks()
    CTQueue.updateTasks()
    MRIQueue.updateTasks()


def insertTaskIntoCorrespondingQueue(task, xray, ct, mri):
    if task.examType == xray.type:
        xray.list.append(task)
    elif task.examType == ct.type:
        ct.list.append(task)
    elif task.examType == mri.type:
        mri.list.append(task)

def readQueueAndAppendJsonFeeds(queue, outfeeds):
    out = outfeeds
    for task in queue.list:
        newdata = {'patient':
                   { 'ownerName' : task.ownerName,
                    'patientName': task.patientName,
                    'isEmergent': task.isEmergent,
                    'patientType': task.patientType,
                    'patientID': task.patientID,
                    'needSedation': task.needSedation,
                    'department': task.department,
                     'examType': task.examType,
                     'specificScan':task.specificScan,
                    'waitingTime': task.waitingTime,
                    'lastSyncedTme':task.lastSyncedTime,
                     'appointmentID':task.appointmentID,
                     'isStarted' : task.isStarted,
                     'estimatedTime' : time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(task.waitingTime + time.time()))
                    }
               }
        out.append(newdata)
    return out

def readJsonAndConstructQueue(jsonData, xrayQueue, CTQueue, MRIQueue):
    for entry in jsonData:
        newTask = createTaskFromJson(entry)
        updateJsonTask(newTask)
        insertTaskIntoCorrespondingQueue(newTask,xrayQueue, CTQueue, MRIQueue )
        updateQueue()

    sortQueues()

def sortQueues():
    CTQueue.list.sort(key=lambda task: task.waitingTime)
    MRIQueue.list.sort(key=lambda task: task.waitingTime)
    xrayQueue.list.sort(key=lambda task: task.waitingTime)

def update():
    if os.path.exists(jsonFile):
        with open(jsonFile, 'r') as intputfile:
            feeds = json.load(intputfile)
            readJsonAndConstructQueue(feeds,xrayQueue, CTQueue, MRIQueue)


    with open(jsonFile, mode='w') as f:
        json.dump([], f)

    with open(jsonFile, mode='r') as f:
        outfeeds = json.load(f)
        outfeeds = readQueueAndAppendJsonFeeds(xrayQueue,outfeeds)
        outfeeds = readQueueAndAppendJsonFeeds(CTQueue, outfeeds)
        outfeeds = readQueueAndAppendJsonFeeds(MRIQueue, outfeeds)

    with open(jsonFile, mode='w') as f:
        print "##############  UPDATING ###############################"
        print json.dumps(outfeeds, indent=4, sort_keys=True)
        json.dump(outfeeds,f)

update()
